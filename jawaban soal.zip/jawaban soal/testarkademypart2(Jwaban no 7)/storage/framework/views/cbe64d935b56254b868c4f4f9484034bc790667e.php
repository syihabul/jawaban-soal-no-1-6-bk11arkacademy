<!DOCTYPE html>
<html>
<head>

<style>
body {
  background-color: lightblue;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;    
}
</style>
</head>
<body>

<h2>Test arkademy</h2>
<p>menggunakan tabel.</p>

<table style="width:100%">
  <tr>
    <th>Nama</th>
    <th>Hobbi</th>
    <th>kategori</th>
  </tr>
  <tr>
    <td>Novi</td>
    <td>Koleksi Tas</td>
    <td>Shopping</td>
  </tr>
  <tr>
    <td>Vita</td>
    <td>Intastory</td>
    <td>Media Sosial</td>
  </tr>
</table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\testarkademypart2\resources\views/testarkademy.blade.php ENDPATH**/ ?>